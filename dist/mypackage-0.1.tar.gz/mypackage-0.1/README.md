# mypackage
This was created as an example of how to publish your own python package.

##building this locally
'python setup.py sdist'

## installing this package from github
'pip install https://github.com/DadaNkosi/example-python-package.git'

## updating this package from github
'pip install --upgrade git+https://github.com/DadaNkosi/example-python-package.git'
